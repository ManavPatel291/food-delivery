import React from 'react'

const Biryani = () => {
  return (
    <div>Biryani</div>
  )
}

export default Biryani