import React from 'react'

const Rolls = () => {
  return (
    <div>Rolls</div>
  )
}

export default Rolls