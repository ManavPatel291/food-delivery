import React from 'react'

const Thali = () => {
  return (
    <div>Thali</div>
  )
}

export default Thali