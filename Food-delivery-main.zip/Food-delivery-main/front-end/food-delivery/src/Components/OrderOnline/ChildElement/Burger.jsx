import React from 'react'

const Burger = () => {
  return (
    <div>Burger</div>
  )
}

export default Burger