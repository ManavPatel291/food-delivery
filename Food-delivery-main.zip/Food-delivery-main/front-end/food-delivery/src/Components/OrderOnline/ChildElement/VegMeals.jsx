import React from 'react'

const VegMeals = () => {
  return (
    <div>VegMeals</div>
  )
}

export default VegMeals