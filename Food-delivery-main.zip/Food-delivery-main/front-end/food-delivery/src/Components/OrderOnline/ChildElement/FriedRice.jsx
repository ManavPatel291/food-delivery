import React from 'react'

const FriedRice = () => {
  return (
    <div>FriedRice</div>
  )
}

export default FriedRice