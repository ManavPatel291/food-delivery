import React from 'react'

const Cake = () => {
  return (
    <div>Cake</div>
  )
}

export default Cake