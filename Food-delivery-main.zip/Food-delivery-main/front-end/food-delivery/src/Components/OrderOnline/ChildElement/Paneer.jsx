import React from 'react'

const Paneer = () => {
  return (
    <div>Paneer</div>
  )
}

export default Paneer