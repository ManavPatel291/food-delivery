import React from 'react'

const DrinksAndNightlife = () => {
  return (
    <div>DrinksAndNightlife</div>
  )
}

export default DrinksAndNightlife