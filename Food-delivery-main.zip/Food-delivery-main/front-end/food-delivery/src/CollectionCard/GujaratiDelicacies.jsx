import React from 'react'

const GujaratiDelicacies = () => {
  return (
    <div>GujaratiDelicacies</div>
  )
}

export default GujaratiDelicacies